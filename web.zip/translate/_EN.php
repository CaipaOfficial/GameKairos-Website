<?php
	
	$Kairos = "KAIROS";
	$BelowKairos = "A new beginning";
	$DownloadNow = "Download now";
	$MoreInfo = "Coming soon...";
  $Success = "Your account has been successfully created!";

	$ButtonTranslate = "English / Inglés";

	$Parrafo = '<p class="lead"><h2 class="text-center">Join us to the biggest community of online players</h2><p class="text-center"><br>
            <b>-With an efficient staff team that will solve all your problems as soon as possible.</b><br>
            <b>-Best <strong>PVE / PVP</strong> and frequent updates.</b><br>
            <b>-secured and immediate donations.</b><br>
            <b>-It is free to play, but also there is no pay to win.</b></p>';

	$RegisteredPlayers = "Total registered players";

	$BeginAdventure = "Begin your new adventure";

	$Top10 = '<h2 class="text-center mb-4 name-server">Top 10</h2>
            <p class="text-center"><b>Players</b> and
              <b>families</b> of highest rank in the game</p>';
              
    $Register = "Register";
    $RegInfo = "<p>
                  Register information: <br>
                  - Do not include symbols when registering, only letters and numbers.<br>
                  - Username has to be 4 to 12 characters lenght.<br>
                  - The password has to be 5 to 16 characters lenght.<br>
                  - Remember to create a password with a bit of difficulty to avoid scammers.<br>
                </p>";

    $Story = "Create your own story!";
    $Player = "Be the best player!";
    $Donations = "Donations";
    $Rules = "Rules";

  ?>