<?php
	
	$Kairos = "KAIROS";
	$BelowKairos = "Un nuevo comienzo";
	$DownloadNow = "Descarga ya";
	$MoreInfo = "Pronto...";
  $Success = "¡Tu cuenta se ha creado con éxito!";

	$ButtonTranslate = "Español / Spanish";

	$Parrafo = '<p class="lead"><h2 class="text-center">Únete ahora la mejor y más activa comunidad de jugadores online</h2><p class="text-center"><br>
            <b>-Con un eficiente equipo de Staff dispuestos a ayudarte en cualquier problema.</b><br>
            <b>-Sistema de juego <strong>PVE / PVP</strong> renovado y actualizaciones constantes.</b><br>
            <b>-Donaciones seguras e inmediatas.</b><br>
            <b>-Libre de pay to win.</b></p>';

	$RegisteredPlayers = "Jugadores registrados";

	$BeginAdventure = "Empieza esta nueva aventura";

	$Top10 = '<h2 class="text-center mb-4 name-server">Top 10</h2>
            <p class="text-center">Los <b>jugadores</b> y las
              <b>familias</b> de mas alto rango en el juego</p>';

    $Register = "Registro";
    $RegInfo = "<p>
                  Información del Registro: <br>
                  - El nombre de usuario sólo puede contener letras y números (no simbolos).<br>
                  - El nombre de usuario debe tener una longitud mayor a 4 caracteres y menor a 12 caracteres.<br>
                  - La longitud minima de contraseña debe ser mayor a 5 y menor a 16 caracteres.<br>
                  - Recuerda crear una contraseña con un mínimo de dificultad para evitar robos.<br>
                </p>";
                
    $Story = "¡Crea tu propia historia!";
    $Player = "¡Sé el mejor jugador!";
  ?>