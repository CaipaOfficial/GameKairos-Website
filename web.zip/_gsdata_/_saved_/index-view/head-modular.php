  <?php
  require ($_SERVER['DOCUMENT_ROOT'].'/db/connect.php');
  require ($_SERVER['DOCUMENT_ROOT'].'/analytics.google/analytics.google.php');
  ?>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>KAIROS</title>
  <meta name="description" content="A free and modern UI toolkit for web makers based on the popular Bootstrap 4 framework.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
    crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/shards.css">
<!--   <link rel="stylesheet" href="particles-js/css/style.css"> -->
  <link rel="stylesheet" href="css/paymentfont.min.css">
  <link rel="stylesheet" href="css/shards-demo.css">
  <link href="https://fonts.googleapis.com/css?family=Cinzel:700" rel="stylesheet">
  <link rel="shortcut icon" href="https://www.gamekairos.org/favico/favicon.ico" />
  <link rel="manifest" href="favico/manifest.json">
  <script src='https://www.google.com/recaptcha/api.js'></script>
