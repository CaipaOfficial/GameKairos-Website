<?php 	



 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<?php require ('https://gamekairos.org/index-view/head-modular.php'); ?>
 </head>
 <body>
 	
 </body>
 </html>