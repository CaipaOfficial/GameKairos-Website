<?php 
require ('../../db/connect.php');
session_start();
var_dump($_SESSION);



 ?>