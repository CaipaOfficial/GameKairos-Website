<?php 


 ?>
  <div class="p-4" style="position:fixed; z-index: 4;top: 0;width: 25%;">
    <form class="form-inline" method="POST" action="index.php" style="position:relative;">  
      <select class="custom-select mb-2 mr-sm-2 mb-sm-0 bg-secondary text-white" id="inlineFormCustomSelect" name="LENGUAJE" style="z-index: 2;">
        <option selected>ESP/ENG</option>
        <option value="EN">English/Ingles</option>
        <option value="ES">Spanish/Español</option>
      </select>
      <button type="submit" class="btn btn-default bg-dark text-white btn-sm">Submit</button>      
    </form>
  </div>