      <div class="footer-cta bg-dark">
        <div class="container my-5">
          <div class="py-5">
            <div class="text-center">
              <h1>🛠</h1>
              <h2 class="text-white na name-server"><?php echo "$Story"; ?></h2>
              <p class="text-muted col-lg-8 col-md-10 ml-auto mr-auto"><?php echo "$Player"; ?>
                <b>
                  <u><!-- u>Go ahead and build somethin -->
                  </u>
                </b><!-- b> Can't wait to see what you come up with! If you like Shards, make sure you share it with your friends to --></p>
            </div>

            <div class="share d-table ml-auto mr-auto mt-5">
              <a href="https://twitter.com/intent/tweet?url=http%3A%2F%2Fwww.gamekarios.org&text=KAIROS%20es%20el%20mejor%20servidor%20de%20aventuras%20online"
                class="btn btn-pill btn-primary mr-4" title="Share Shards on Twitter">
                <i class="fa fa-twitter mr-1"></i> Share on Twitter</a>
              <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.gamekarios.org" class="btn btn-pill btn-primary mr-4" title="Share on Facebook">
                <i class="fa fa-facebook mr-1"></i> Share on Facebook</a>
              <a href="http://www.linkedin.com/shareArticle?mini=true&url=http%3A%2F%2Fwww.gamekarios.org&title=KAIROS%20es%20el%20mejor%20servidor%20de%20aventuras%20online"
                class="btn btn-pill btn-primary mr-4" title="Share on LinkedIn">
                <i class="fa fa-linkedin mr-1"></i> Share on LinkedIn</a>
            </div>
          </div>
        </div>
      </div>

      <footer class="main-footer py-5">
        <p class="text-muted text-center small p-0 mb-4">&copy; Copyright 2018 — DesignRevision</p>
        <div class="social d-table mx-auto">
          <a class="twitter mx-3 h4 d-inline-block text-secondary" href="https://twitter.com/DesignRevision" target="_blank">
            <i class="fa fa-twitter"></i>
            <span class="sr-only">View our Twitter Profile</span>
          </a>
          <a class="facebook mx-3 h4 d-inline-block text-secondary" href="https://www.facebook.com/designrevision" target="_blank">
            <i class="fa fa-facebook"></i>
            <span class="sr-only">View our Facebook Profile
              <span>
          </a>
          <a class="github mx-3 h4 d-inline-block text-secondary" href="https://github.com/designrevision" target="_blank">
            <i class="fa fa-github"></i>
            <span class="sr-only">View our GitHub Profile</span>
          </a>
        </div>
      </footer>