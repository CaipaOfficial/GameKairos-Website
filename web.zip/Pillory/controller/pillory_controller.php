<?php

$options =  array( "Scrollable" => SQLSRV_CURSOR_STATIC );

 ?>
