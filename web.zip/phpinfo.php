<?php
//phpinfo();
echo "Que coño miras";
 ?>
