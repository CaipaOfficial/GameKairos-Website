<?php 	



 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<?php include ('../index-view/head-modular.php'); ?>
 </head>
 <body>
 	
 </body>
 </html>