<!DOCTYPE html>
<html lang="en">
<head>




    <!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-57419903-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-57419903-1');
	</script>
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-57419903-2"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-57419903-2');
  </script>  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>KAIROS</title>
  <meta name="description" content="The best MMORPG game, download it now!">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
    crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/shards.css">
<!--   <link rel="stylesheet" href="particles-js/css/style.css"> -->
  <link rel="stylesheet" href="https://gamekaiors.org/css/paymentfont.min.css">
  <link rel="stylesheet" href="https://gamekaiors.org/css/shards-demo.css">
  <link href="https://fonts.googleapis.com/css?family=Cinzel:700" rel="stylesheet">
  <link rel="shortcut icon" href="https://www.gamekairos.org/favico/favicon.ico" />
  <link rel="manifest" href="favico/manifest.json">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body style="
    background-image: url('../../images/paysafe/bg.jpg');
    background-repeat: no-repeat;
    background-size: 105%;
"> <div class="card container pb-5 text-center">
      <div class="container text-center p-5">
          <h1>Payment</h1>
          <p>Make a payment with paysafecard <img src="https://www.paysafecard.com/fileadmin/Website/Dokumente/B2B/logo_paysafecard.jpg" height="48px" /></p>
      </div>
      <div class="container" aligm="center">
            <h4 class="text-center p-3 mb-2 bg-danger text-white"><p> To do a paysafecard transaction, please contact Delox via Discord (Delox#8256) or send a mail to Kairos.paysafecard@gmail.com. This is because we are looking for the most security possible with this payment method.</p></h4>
                  <div class="container theme-showcase" role="main" align="center">
                    <div align="center">
                          <div class="col-6 m-1 text-center" align="center">
                              <p>
                                <div class="p-2 mb-2 bg-info text-white rounded">
                                  <h3>10€ Donation Pack</h3><br>
                                  - 15 Akamur Coupon (VIP coin)
                                </div>
                              </p><br>
                              <p>
                                <div class="p-2 mb-2 bg-secondary text-white">
                                  <h3>25€ Donation (Special October Pack)</h3><br>
                                  - 50x Akamur Coupon (VIP coin)<br>
                                  - 1x SPECIAL PRIZE
                                </div>
                              </p><br>
                          </div>
                          <div class="col-6 m-1 text-center">
                              <p>
                                <div class="p-2 mb-2 bg-primary text-white rounded">
                                  <h3>50€ Donation Pack</h3><br>
                                  - 125 Akamur Coupon (VIP coin)
                                </div>
                              </p><br>
                              <p>
                                <div class="p-2 mb-2 bg-warning text-dark rounded">
                                  <h3>100€ Donation Pack</h3><br>
                                  - 300 Akamur Coupon (VIP coin)
                                </div>
                              </p><br>
                              <p>
                                <div class="p-2 mb-2 bg-primary text-white rounded">
                                  <h3>200€ Donation Pack (Only available on paypal)</h3><br>
                                  - 700 Akamur Coupon (VIP coin)
                                </div>
                              </p><br>
                          </div>
                    </div>
                    <script>
    (function (d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s);
      js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=1662270373824826";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

  </script>
    <!--  Adsens -->
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <script>
    (adsbygoogle = window.adsbygoogle || []).push({
      google_ad_client: "ca-pub-9027741837304821",
      enable_page_level_ads: true
    });
  </script>
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
  <script src="js/shards.min.js"></script>
  <script src="js/demo.min.js"></script>                </div>

      </div>
  </div>
</body>
</html>